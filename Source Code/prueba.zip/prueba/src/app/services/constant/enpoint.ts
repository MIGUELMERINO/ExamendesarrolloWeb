export class ENPOINT {
    AUTH: 'auth';
    USUARIO: 'usuarios';
}
