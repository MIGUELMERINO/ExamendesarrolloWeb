export class APIs{
    APIs = 'http://localhost:8080/';
}
