import { Injectable } from '@angular/core';
import { CrudService } from '../../services/crud/crud.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private crud: CrudService) { }

  authUser(user: string, password: string){
    return this.crud.get(`auth/${user}/${password}`);
  }


}
