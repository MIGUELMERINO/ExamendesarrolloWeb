import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { AuthService } from './auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  login: FormGroup;

  showMessage: boolean;

  constructor(
    private form: FormBuilder,
    private router: Router,
    private translate: TranslateService,
    private auth: AuthService
    ) {
    this.showMessage = true;
    this.login = this.form.group({
      usuario: ['', [Validators.required, Validators.minLength(6)]],
      password: ['', [Validators.required, Validators.minLength(8)]],
      traduction: ['es']
    });
  }

  ngOnInit(): void {
    this.login.get('traduction').valueChanges.subscribe(res => {
      this.translate.setDefaultLang(res);
    });
  }

  loginUser(login){
    console.log(login);
    this.auth.authUser(login.usuario, login.password).subscribe( result => {
      const letgh = Object.keys(result).length;
      if (letgh > 0 ) {
        this.router.navigate(['/menu']);
      } else {
        this.showMessage = false;
        setTimeout(() => {
          this.showMessage = true;
        }, 2000);
      }
    }, error => console.error(error));
  }
}
