package com.pruebaBranchBit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PruebaBranchBitApplication {

	public static void main(String[] args) {
		SpringApplication.run(PruebaBranchBitApplication.class, args);
	}

}
